﻿namespace HttpServer.Framework.core.Attributes;

[AttributeUsage(AttributeTargets.Class)]
public class EndpointAttribute : Attribute
{
}