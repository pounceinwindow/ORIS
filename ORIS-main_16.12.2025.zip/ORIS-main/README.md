# ORIS  
  Верстка сайта: "Страница поиска" + "chatgpt"  
  
  HttpListener. Практика 1 (HTTP-сервер на C# , "Страница поиска")					
  
  HttpListener. Практика 2 (Статические файлы, передача типов файлов)					
  
  HttpListener. Практика 3-4 (Передача параметров из query в метод endpoint. Обработка ошибок)					
  
  HttpListener. Практика 3-4. (Отправка сообщения на почту)					
  
  HttpListener. Практика 5. (Библиотека, HtmlTemplater)					
  
  HttpListener. Практика 6-7. (Библиотека - Orm)					

  HomeWork_8 — DotAndGame. Игра на WinForm и MAUI (клиент–сервер)